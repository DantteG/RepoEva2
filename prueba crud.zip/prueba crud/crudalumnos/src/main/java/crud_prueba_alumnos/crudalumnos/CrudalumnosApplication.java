package crud_prueba_alumnos.crudalumnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudalumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudalumnosApplication.class, args);
	}

}
